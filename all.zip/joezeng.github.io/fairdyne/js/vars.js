const SHIELD_DISTANCE = 32;
const HEART_SIZE = 16;

const BOX_ADJUST_SPEED = 0.5; // px/ms
const MOVEMENT_SPEED = 0.16; // px/ms
const SPEAR_SPEED = 0.25;