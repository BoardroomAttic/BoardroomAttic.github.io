var pk1 = {
    type: "pike",
    next_time: 6.4,
    buffer_time: 0.3,
    pike_interval: 400,
    down: false,
    next_sets: ["g_ag1"],
};

var ca1 = {
    type: "circlespear",
    next_time: 6.4,
    buffer_time: 0.3,
    spear_interval: 1.2,
    spear_count: 7,
    next_sets: ["g_ag1"],
};